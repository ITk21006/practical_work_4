export const API_KEY = 'aabdb22f8c0c48a8a8169096c5d4cca3';
export const endpoint = `https://newsapi.org/v2/top-headlines`;
export const country = 'us';